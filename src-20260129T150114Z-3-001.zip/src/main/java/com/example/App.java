package com.example;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Jenkins!");
    }

    public static int add(int a, int b) {
        return a + b;
    }
}
